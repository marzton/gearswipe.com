#!/bin/bash

# Define domain folders and custom taglines
declare -A DOMAINS=(
  ["wordpress/rmarston.com"]="Personal Portfolio of R. Marston"
  ["solefoodny.com"]="NYC's Premier Sole Food"
  ["armsway.com"]="Tactical Innovation, Built to Last"
  ["gearswipe.com"]="Swipe Smarter. Gear Better."
  ["goldshore.org"]="Empowering Innovation with Purpose"
  ["tangentmachine.com"]="Precision Ideas, Tangent Execution"
  ["armsway.net"]="The Digital Wing of ARMSWAY"
  ["goldshorefoundation.org"]="Where Impact Meets Execution"
)

HTACCESS_SRC="$HOME/public_html/.htaccess"
BASE_PATH="$HOME/public_html"

for dir in "${!DOMAINS[@]}"; do
  SITE_PATH="$BASE_PATH/$dir"
  TITLE="${dir##*/}"
  TAGLINE="${DOMAINS[$dir]}"

  # Create dir if missing
  if [ ! -d "$SITE_PATH" ]; then
    echo "📁 Creating: $SITE_PATH"
    mkdir -p "$SITE_PATH"
  fi

  # Sync .htaccess
  echo "📄 Syncing .htaccess to: $SITE_PATH"
  cp -f "$HTACCESS_SRC" "$SITE_PATH/.htaccess"

  # Generate synthwave index.html with subscribe box
  if [ ! -f "$SITE_PATH/index.html" ] && [ ! -f "$SITE_PATH/index.php" ]; then
    echo "📝 Generating index.html for $TITLE"
    cat << HTML > "$SITE_PATH/index.html"
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8"/>
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>$TITLE</title>
  <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@500&display=swap" rel="stylesheet">
  <style>
    body {
      margin: 0;
      padding: 0;
      font-family: 'Orbitron', sans-serif;
      background: linear-gradient(to top, #0f0c29, #302b63, #24243e);
      color: #fff;
      display: flex;
      flex-direction: column;
      justify-content: center;
      align-items: center;
      height: 100vh;
      background-image: url('https://wallpaperaccess.com/full/2112856.jpg');
      background-size: cover;
      background-position: center;
    }
    .overlay {
      background-color: rgba(0,0,0,0.6);
      padding: 2em;
      border-radius: 12px;
      text-align: center;
      max-width: 600px;
    }
    h1 {
      font-size: 3.5em;
      margin-bottom: 0.3em;
      text-shadow: 0 0 15px #ff00ff, 0 0 30px #00ffff;
    }
    p {
      font-size: 1.3em;
      color: #ccc;
      margin-bottom: 2em;
    }
    form {
      display: flex;
      justify-content: center;
      gap: 10px;
      flex-wrap: wrap;
    }
    input[type="email"] {
      padding: 0.7em;
      border: none;
      border-radius: 5px;
      width: 250px;
    }
    button {
      padding: 0.7em 1.5em;
      background-color: #00ffff;
      color: #000;
      border: none;
      border-radius: 5px;
      font-weight: bold;
      cursor: pointer;
    }
    button:hover {
      background-color: #ff00ff;
      color: #fff;
    }
  </style>
</head>
<body>
  <div class="overlay">
    <h1>$TITLE</h1>
    <p>$TAGLINE</p>
    <form action="#" method="POST" onsubmit="alert('Thank you! We’ll keep you posted.'); return false;">
      <input type="email" name="email" placeholder="Enter your email for updates" required />
      <button type="submit">Subscribe</button>
    </form>
  </div>
</body>
</html>
HTML
  fi
done

echo "✅ Synced .htaccess and deployed synthwave splash pages with email capture."
