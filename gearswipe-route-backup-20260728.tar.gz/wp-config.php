<?php
/**
 * The base configuration for WordPress.
 *
 * This file dynamically assigns database settings based on the current domain.
 */

// Determine the site from the HTTP host
$site = $_SERVER['HTTP_HOST'];

// Configure database credentials based on the domain
switch ($site) {
    case 'rmarston.com':
        define('DB_NAME', 'trebweb_rmarston');
        define('DB_USER', 'trebweb_rmarston');
        define('DB_PASSWORD', 'Ineed@least10chars!'); // Replace with the actual password
        define('DB_HOST', 'localhost');
        break;

    case 'gearswipe.com':
        define('DB_NAME', 'trebweb_gearswipe');
        define('DB_USER', 'trebweb_gs');
        define('DB_PASSWORD', 'Ineed@least10chars!'); // Replace with the actual password
        define('DB_HOST', 'localhost');
        break;

    case 'goldshore.org':
        define('DB_NAME', 'trebweb_goldshore');
        define('DB_USER', 'trebweb_wpgsf');
        define('DB_PASSWORD', 'Ineed@least10chars!'); // Replace with the actual password
        define('DB_HOST', 'localhost');
        break;

    case 'tangentmachine.com':
        define('DB_NAME', 'trebweb_tangent');
        define('DB_USER', 'trebweb_tangent');
        define('DB_PASSWORD', 'Ineed@least10chars!'); // Replace with the actual password
        define('DB_HOST', 'localhost');
        break;

    case 'armsway.net':
        define('DB_NAME', 'trebweb_armsway');
        define('DB_USER', 'trebweb_wp538');
        define('DB_PASSWORD', 'Ineed@least10chars!'); // Replace with the actual password
        define('DB_HOST', 'localhost');
        break;

    default:
        die("No database configuration found for $site.");
}

// Database charset to use in creating database tables
define('DB_CHARSET', 'utf8');

// The database collate type. Don't change this if in doubt
define('DB_COLLATE', '');

// Authentication unique keys and salts
define('AUTH_KEY',         'KE,BnB[;j.fIe{G6vy1v5hpotkN~Leo_xH+3 fIcVUA|c(Vp= {-I.lqt4 hDfa+');
define('SECURE_AUTH_KEY',  'ml(,1nlm ?p87Su.*>M`v0BN#7(+T}0v5}2}+f-b-{[y=pN;f,:1BE-j^9r2GeZe');
define('LOGGED_IN_KEY',    '78&b}=4dnwQjM_jjiYjDz-5s=htsF5tsZ3qd1WeXyjAvtLuWRYB{GrV;-kbs6W,{');
define('NONCE_KEY',        'S!^aD#-{lol3+$bONB:XlK+FS*$(<11w`[B|$%y}`wOp.|.pwEKJ4kS%P[#hVIY|');
define('AUTH_SALT',        '6Zr^c}i)`8X+f%wD&7+R58u{+]Vi>vvm_:vsg.<]e-Ct|Ba@TI pF+yV,TSw0,0i');
define('SECURE_AUTH_SALT', 'lml}MgC1Ly$!+J,*|^j)eIg8tM$v)A!Fe&S+yDf=35L+P%:VD=cBAb*gK)4GM]FE');
define('LOGGED_IN_SALT',   '#;Q]+6|lGjT/h~X:+E]o.B.D<{db7)5o.rgbfF|AIQE~<PkeO^Yh1{cX2tO4Tl5m');
define('NONCE_SALT',       '/R@Wcu.r$O^Gp@$Eh(DJYB)n8~>zt!$@{X]6oCBohsam!M!P#1rD`>AqEli+plu(');

// WordPress database table prefix
$table_prefix = 'wp_';

// For developers: WordPress debugging mode
define('WP_DEBUG', true);

/* Add any custom values between this line and the "stop editing" line */

// Media Upload Directory Customization
define('UPLOADS', 'wp-content/uploads/' . strtolower($site));

define('DISALLOW_FILE_EDIT', true);

define('CONCATENATE_SCRIPTS', false);

/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if (!defined('ABSPATH')) {
    define('ABSPATH', __DIR__ . '/');
}

/** Sets up WordPress vars and included files */
require_once ABSPATH . 'wp-settings.php';
