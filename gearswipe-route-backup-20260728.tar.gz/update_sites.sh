#!/bin/bash
echo '🚀 Updating .htaccess and index.php for all domain folders...'

DOMAIN_DIRS=(
  "rmarston.com"
  "solefoodny.com"
  "armsway.com"
  "gearswipe.com"
  "armsway.net"
  "goldshorefoundation.org"
  "tangentmachine.com"
)

HTACCESS_CONTENT=$(cat <<'EOF'
# Enable rewrite engine
RewriteEngine On

# ✅ Canonical Redirect: Domains to rmarston.com
RewriteCond %{HTTP_HOST} 
^(www\.)?(goldshore\.org|gearswipe\.com|tangentmachine\.com|armsway\.com|solefoodny\.com|armsway\.net|goldshorefoundation\.com)$ 
[NC]
RewriteRule ^(.*)$ https://rmarston.com/$1 [L,R=301]

<IfModule mod_headers.c>
  Header set X-Content-Type-Options "nosniff"
  Header set X-Frame-Options "SAMEORIGIN"
  Header set X-XSS-Protection "1; mode=block"
</IfModule>

Options -Indexes
EOF
)

INDEX_PHP_CONTENT=$(cat <<'EOF'
<?php
echo "<h1>Coming Soon</h1>";
?>
EOF
)

for domain in "${DOMAIN_DIRS[@]}"; do
  echo "🔧 Updating: $domain"
  full_path="/home3/trebweb/public_html/$domain"
  mkdir -p "$full_path"

  echo "$HTACCESS_CONTENT" > "$full_path/.htaccess"
  echo "$INDEX_PHP_CONTENT" > "$full_path/index.php"
  chmod 644 "$full_path/.htaccess" "$full_path/index.php"
done

echo "✅ Placeholder for SSL certificate revalidation (manual or API)"

