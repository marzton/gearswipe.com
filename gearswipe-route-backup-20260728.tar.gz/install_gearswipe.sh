#!/bin/bash

# === GearSwipe WordPress Install Script ===
SITE_DIR="$HOME/public_html/gearswipe.com"
DB_NAME="trebweb_gearswipe"
DB_USER="trebweb_gearswipe"
DB_PASS="Ineed@least10chars!"
SITE_URL="https://gearswipe.com"

echo "Creating GearSwipe WordPress directory..."
mkdir -p "$SITE_DIR"
cd "$SITE_DIR" || exit 1

echo "Downloading WordPress..."
curl -sO https://wordpress.org/latest.tar.gz

echo "Extracting WordPress..."
tar -xzf latest.tar.gz --strip-components=1
rm -f latest.tar.gz

echo "Configuring wp-config.php..."
cp wp-config-sample.php wp-config.php
sed -i "s/database_name_here/$DB_NAME/" wp-config.php
sed -i "s/username_here/$DB_USER/" wp-config.php
sed -i "s/password_here/$DB_PASS/" wp-config.php

echo "Setting correct permissions..."
find "$SITE_DIR" -type d -exec chmod 755 {} \;
find "$SITE_DIR" -type f -exec chmod 644 {} \;

echo "✅ GearSwipe WordPress installed at $SITE_DIR"
